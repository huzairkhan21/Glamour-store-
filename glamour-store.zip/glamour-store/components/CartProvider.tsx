'use client'
import {createContext,useContext,useEffect,useMemo,useState} from 'react'
import {CartItem,cartSubtotal,formatINR} from '../lib/cart'
import {Product} from '../lib/products'
type Ctx={items:CartItem[];add:(p:Product)=>void;remove:(id:string)=>void;setQty:(id:string,q:number)=>void;clear:()=>void;subtotal:number;count:number}
const CartContext=createContext<Ctx|null>(null)
export function CartProvider({children}:{children:React.ReactNode}){const [items,setItems]=useState<CartItem[]>([]);useEffect(()=>{try{setItems(JSON.parse(localStorage.getItem('glamour-cart')||'[]'))}catch{}},[]);useEffect(()=>{localStorage.setItem('glamour-cart',JSON.stringify(items))},[items]);const value=useMemo(()=>({items,add:(p:Product)=>setItems(x=>{const e=x.find(i=>i.product.id===p.id);return e?x.map(i=>i.product.id===p.id?{...i,quantity:i.quantity+1}:i):[...x,{product:p,quantity:1}]}),remove:(id:string)=>setItems(x=>x.filter(i=>i.product.id!==id)),setQty:(id:string,q:number)=>setItems(x=>q<1?x.filter(i=>i.product.id!==id):x.map(i=>i.product.id===id?{...i,quantity:Math.min(q,i.product.stock)}:i)),clear:()=>setItems([]),subtotal:cartSubtotal(items),count:items.reduce((s,i)=>s+i.quantity,0)}),[items]);return <CartContext.Provider value={value}>{children}</CartContext.Provider>}
export const useCart=()=>{const c=useContext(CartContext);if(!c)throw new Error('useCart must be inside CartProvider');return c}
export {formatINR}
